/*
  Script to initialise environment: creates required tables and schema for package to run
*/


USE AdventureWorks
GO

--  Create Loading schema
IF not exists (SELECT null FROM sys.schemas WHERE NAME = 'Loading')

EXEC('CREATE SCHEMA Loading')
go

--  The next query creates a simple loading table that will store the NZD exchange rates after they are collected from the API.
IF not exists (SELECT null FROM sys.tables a join sys.schemas b ON a.schema_id = b.schema_id WHERE a.name = 'NZDExchangeRates' and b.name = 'Loading')

  CREATE TABLE
    Loading.NZDExchangeRates
    (
      ExchangeRateDate  varchar(20),
      ExchangeRate      varchar(20)
    )

go


--  The following creates Sales.CurrencyRate if it doesn't exist (Should already exist in the AdventureWorks database but I thought it worth adding this for completeness)
IF not exists (SELECT null FROM sys.tables a join sys.schemas b on a.schema_id = b.schema_id WHERE a.name = 'CurrencyRate' and b.name = 'Sales')
BEGIN
  CREATE TABLE
    Sales.CurrencyRate
    (
      CurrencyRateID    int,
      CurrencyRateDate  datetime,
      FromCurrencyCode  nchar(3),
      ToCurrencyCode    nchar(3),
      AverageRate       money,
      EndOfDayRate      money,
      ModifiedDate      datetime,

      CONSTRAINT PK_CurrencyRate_CurrencyRateID PRIMARY KEY (CurrencyRateID),
      CONSTRAINT FK_CurrencyRate_Currency_FromCurrencyCode FOREIGN KEY (FromCurrencyCode) REFERENCES Sales.Currency(CurrencyCode),
      CONSTRAINT FK_CurrencyRate_Currency_ToCurrencyCode FOREIGN KEY (ToCurrencyCode) REFERENCES Sales.Currency(CurrencyCode),
    )

  CREATE UNIQUE INDEX AK_CurrencyRate_CurrencyRateDate_FromCurrencyCode_ToCurrencyCode ON Sales.CurrencyRate(CurrencyRateDate,FromCurrencyCode,ToCurrencyCode)

END
go



--  Finally the below creates the FactUSOrders table on AdventureWorksDW
USE AdventureWorksDW
GO

IF not exists (SELECT null from sys.tables where name = 'FactUSOrders')
BEGIN
  
  CREATE TABLE
    FactUSOrders
    (
      SalesOrderKey         int,
      SalesOrderNumber      nvarchar(25),
      SalesOrderLineNumber  smallint,
      ProductKey            int,
      Quantity              smallint,
      UnitPriceUSD          money,
      UnitPriceNZD          money,
      UnitPriceDiscountUSD  money,
      UnitPriceDiscountNZD  money,
      LineTotalUSD          money,
      LineTotalNZD          money,
      OrderDateKey          int,

      CONSTRAINT pk_SalesOrderID_SalesOrderLineNumber PRIMARY KEY (SalesOrderKey, SalesOrderLineNumber)
    )

END