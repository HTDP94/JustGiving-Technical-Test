/*
    This script builds the final FactUSOrders table in the AdventureWorksDW database
*/

USE AdventureWorks
GO

--  This first query pulls orders data into a temp table and formats it ready for the FactUSOrders table
SELECT
  a.SalesOrderID AS SalesOrderKey,
  b.SalesOrderNumber,
  row_number() OVER(PARTITION BY a.SalesOrderID ORDER BY a.SalesOrderDetailID) AS SalesOrderLineNumber,
  a.ProductID AS ProductKey,
  a.OrderQty AS Quantity,
  a.UnitPrice AS UnitPriceUSD,
  cast(null AS money) AS UnitPriceNZD,
  a.UnitPriceDiscount AS UnitPriceDiscountUSD,
  cast(null AS money) AS UnitPriceDiscountNZD,
  a.LineTotal AS LineTotalUSD,
  cast(null AS money) AS LineTotalNZD,
  convert(date, b.OrderDate, 12) as OrderDate,
  convert(int, replace(convert(varchar(10), convert(date, b.OrderDate, 112)),'-','')) as OrderDateKey
INTO 
  #TempSalesOrders
FROM
  Sales.SalesOrderDetail a
    join
      Sales.SalesOrderHeader b
      on a.SalesOrderID = b.SalesOrderID


--  The following query then updates the NZD fields using the CurrencyRate table

CREATE CLUSTERED INDEX idx_uc_DateKey ON #TempSalesOrders(OrderDate)
GO

UPDATE
  #TempSalesOrders
SET
  UnitPriceNZD = a.UnitPriceUSD * b.AverageRate,
  UnitPriceDiscountNZD = a.UnitPriceDiscountUSD * b.AverageRate,
  LineTotalNZD = a.LineTotalUSD * b.AverageRate
FROM  
  #TempSalesOrders a
    join
      Sales.CurrencyRate b
      on a.OrderDate = convert(date,b.CurrencyRateDate)
      and b.FromCurrencyCode = 'USD'
      and b.ToCurrencyCode = 'NZD'


DROP INDEX idx_uc_DateKey ON #TempSalesOrders
GO

--  Finally the new data is inserted into the FactUSOrders table 

CREATE UNIQUE CLUSTERED INDEX idx_SalesOrderID_SalesOrderLineNumber ON #TempSalesOrders (SalesOrderKey,SalesOrderLineNumber)
GO

INSERT INTO
  AdventureWorksDW.dbo.FactUSOrders
  (
    SalesOrderKey         ,
    SalesOrderNumber      ,
    SalesOrderLineNumber  ,
    ProductKey            ,
    Quantity              ,
    UnitPriceUSD          ,
    UnitPriceNZD          ,
    UnitPriceDiscountUSD  ,
    UnitPriceDiscountNZD  ,
    LineTotalUSD          ,
    LineTotalNZD          ,
    OrderDateKey          
  )
SELECT
  SalesOrderKey       ,
  SalesOrderNumber    ,
  SalesOrderLineNumber,
  ProductKey          ,
  Quantity            ,
  UnitPriceUSD        ,
  UnitPriceNZD        ,
  UnitPriceDiscountUSD,
  UnitPriceDiscountNZD,
  LineTotalUSD        ,
  LineTotalNZD        ,
  OrderDateKey  
FROM
  #TempSalesOrders a
WHERE
  not exists (SELECT null FROM AdventureWorksDW.dbo.FactUSOrders b WHERE a.SalesOrderKey = b.SalesOrderKey and a.SalesOrderLineNumber = b.SalesOrderLineNumber)


