/*
  The aim of this script is to clean the NZD ExchangeRate data that has been imported into the Loading.NZDExchangeRates
  table and process it into the Sales.CurrencyRate table.

  When working on this section I realised the API wasn't returning exchange rate data for all the days requested (338 days 
  between 2011-05-31 and 2014-06-30 were missing). As a result, for these missing days I decided to set the exchange rate  
  equal to the exchange rate of the previous day (or the last provided date if the previous day is also missing).
  
  I realise this isn't a perfect solution but I thought it was appropriate for now to prevent missing orders in the final
  table. If I encountered this issue at work, I'd raise it with other team members involved to confirm this approach
  seemed reasonable or discuss other potential solutions.
*/

USE AdventureWorks
GO


--  Firstly, the below recursive function creates a temp table of all dates between 2011-05-31 and 2014-06-30
DECLARE @FromDate date = '2011-05-31'
DECLARE @ToDate date = '2014-06-30'

;WITH cte_dates AS
(
  SELECT
    @FromDate AS Date
  UNION ALL
  SELECT
    dateadd(day, 1, Date)
  FROM
    cte_dates
  WHERE
    Date < @ToDate
)
SELECT
  *
INTO
  #tmp_dates
FROM
  cte_dates
OPTION
  (MaxRecursion 1500) 

--  Next, this #tmp_dates table is used in a left join to create a temporary currency rate table in preparation for insertion into Sales.CurrencyRate
SELECT DISTINCT
  convert(datetime, a.Date)     AS CurrencyRateDate,
  'USD'                         AS FromCurrencyCode,
  'NZD'                         AS ToCurrencyCode,
  convert(money, ExchangeRate)  AS AverageRate,
  convert(money, ExchangeRate)  AS EndOfDayRate,
  sysdatetime()                 AS ModifiedDate
INTO   
  #tmp_CurrencyRate
FROM  
  #tmp_dates a
    left outer join 
      Loading.NZDExchangeRates b
      ON a.Date = convert(date, b.ExchangeRateDate)


--  The below while loop goes through each row of #tmp_CurrencyRate and either sets the AverageRate to the most recent 
--  AverageRate if it's value is null, or updates the most recent AverageRate if it's not null.

DECLARE @MostRecentAverageRate money = null

WHILE @FromDate <= @ToDate
BEGIN
  
  IF (SELECT AverageRate FROM #tmp_CurrencyRate WHERE convert(date,CurrencyRateDate) = @FromDate) is null
    BEGIN
      UPDATE
        #tmp_CurrencyRate
      SET
        AverageRate = @MostRecentAverageRate
      WHERE
        convert(date,CurrencyRateDate) = @FromDate
    END
  ELSE
    SELECT @MostRecentAverageRate = AverageRate FROM #tmp_CurrencyRate WHERE convert(date,CurrencyRateDate) = @FromDate


  SET @FromDate = dateadd(day, 1, @FromDate)

END


--  Finally these records are inserted into Sales.CurrencyRate if they don't exist
INSERT INTO
  Sales.CurrencyRate
  (
    CurrencyRateDate,
    FromCurrencyCode,
    ToCurrencyCode,
    AverageRate,
    EndOfDayRate,
    ModifiedDate
  )
SELECT 
  CurrencyRateDate,
  FromCurrencyCode,
  ToCurrencyCode,
  AverageRate,
  AverageRate,
  sysdatetime() AS ModifiedDate
FROM 
  #tmp_CurrencyRate a
WHERE
  not exists (SELECT null FROM Sales.CurrencyRate b WHERE convert(date, a.CurrencyRateDate) = convert(date, b.CurrencyRateDate) and b.FromCurrencyCode = 'USD' and b.ToCurrencyCode = 'NZD' )

