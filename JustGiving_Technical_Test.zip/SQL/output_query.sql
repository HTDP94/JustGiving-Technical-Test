/*
  This query produces the desired outcome 
*/

use AdventureWorksDW
go

select
  c.CalendarYear,
  b.Color,
  sum(LineTotalUSD) as Total_Sales_USD,
  sum(LineTotalNZD) as Total_Sales_NZD,
  sum(Quantity) as Total_Quantity_Ordered
from
  FactUSOrders a
    join
      AdventureWorks.Production.Product b
      on a.ProductKey = b.ProductID
    join
      DimDate c
      on a.OrderDateKey = c.DateKey
group by
  c.CalendarYear,
  b.Color
order by
  1,2
